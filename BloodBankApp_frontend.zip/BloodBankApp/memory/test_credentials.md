# Blood Bank & Donor Locator - Demo Credentials
> All accounts are created automatically at server startup by
> `/app/server/database/init.js`. If you re-seed, credentials remain identical.

## Admin
- **Email:** admin@redpulse.dev
- **Password:** admin@123

## Donor (Demo)
- **Email:** donor.john@redpulse.dev
- **Password:** password123
- Blood Group: O- (Universal Donor)

## Recipient (Demo)
- **Email:** recipient.msh@redpulse.dev
- **Password:** password123
- Blood Group: B+

## Other donor accounts (same password: `password123`)
| Name          | Email                        | Blood | City             |
|---------------|------------------------------|-------|------------------|
| Priya Sharma  | donor.priya@redpulse.dev     | B+    | Brooklyn, NY     |
| Marcus Lee    | donor.marcus@redpulse.dev    | A+    | Queens, NY       |
| Sofia Rossi   | donor.sofia@redpulse.dev     | AB+   | Bronx, NY        |
| Kwame Osei    | donor.kwame@redpulse.dev     | B-    | Manhattan, NY    |
| Emily Chen    | donor.emily@redpulse.dev     | O+    | Jersey City, NJ  |
| Ravi Kapoor   | donor.ravi@redpulse.dev      | A-    | Brooklyn, NY (pending verification) |
| Hannah Miller | donor.hannah@redpulse.dev    | AB-   | Manhattan, NY (unavailable) |

## Quick Demo Login
The frontend's `AuthModal` also has one-click demo login buttons that call
`POST /api/auth/demo-login` and log you in as `donor`, `recipient` or `admin`
without typing credentials.
